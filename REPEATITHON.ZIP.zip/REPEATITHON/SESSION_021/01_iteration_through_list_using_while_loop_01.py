# Create list list L1:
L1_rj = [10, 20, 30, 40, 50] 
# Without loop each individual access will require a separate
# statement
# Access element at index 0
n_rj = L1_rj[0]
print('Element at index 0:', n_rj)

# Access element at index 1
n_rj = L1_rj[1]
print('Element at index 1:', n_rj)

# Access element at index 2
n_rj = L1_rj[2]
print('Element at index 2:', n_rj)

# Access element at index 3
n_rj = L1_rj[3]
print('Element at index 3:', n_rj) 

# Access element at index 4
n_rj = L1_rj[4]
print('Element at index 4:', n_rj)
#-----------------------------------
print('Accessing and printing list values using while loop:')

# Write loop variable initialization, loop variable condition
# and loop variable modification so that the loop variable
# goes through the valid index range
i_rj = 0 # initialize loop variable with the first valid index
while i_rj < len(L1_rj):
    n_rj = L1_rj[i_rj]
    print('Element at index:', i_rj, 'is:', n_rj)
    i_rj = i_rj + 1 