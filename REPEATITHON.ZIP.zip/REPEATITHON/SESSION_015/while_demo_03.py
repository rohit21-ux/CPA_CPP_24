#This program  illustrates an infinite loop
#you must press ctrl + c to terminate the program

while True:
    print('Hello!, CPA Python 49 batch')
    a_rj=10
    b_rj=20
    c_rj=a_rj+b_rj
    print('Addition of-:',a_rj,'and',b_rj,'is',c_rj)