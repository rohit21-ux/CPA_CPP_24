print('Start of program')
i_rj=1
while i_rj<= 10:
    if i_rj % 2 == 0:
        print(i_rj,'is an even number')
    else:
        print(i_rj,'is an odd number')
    i_rj =i_rj+1
print('End of while loop:End value of i_rj:',i_rj)
print('End of program')
 