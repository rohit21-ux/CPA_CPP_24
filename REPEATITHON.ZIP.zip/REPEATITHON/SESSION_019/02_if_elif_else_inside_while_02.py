print('start of program')
i_rj= -5
while i_rj <= 5:
    if i_rj>0:
        print(i_rj,'is positive')
    elif i_rj<0:
        print(i_rj,'is negative')
    else:
        print(i_rj,'is zero')
    i_rj=i_rj +1
print('End of while loop.End value of i_rj:',i_rj)
print('End of program')