Python 3.12.8 (tags/v3.12.8:2dc476b, Dec  3 2024, 19:30:04) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
#Session 010 : Repeatithon 01
# create int 100 and name it as 'a'
a=100
#create integer 5 and name it as 'numberOfRepeatithons'
>>> numberOfRepeatitions =5
>>> #create an integer 120 and name it as'NumberOfSessions'
>>> NumberOfsessions =125
>>> #Create an integer 145 and name it as'number_of_admissions'
>>> number_of_admissions=145
>>> #Create an integer 40 and name it as duratiomInhours
>>> durationInhours=40
>>> a=100
>>> a=100
>>> a=100
>>> a=100
>>> a=100
>>> # a=100,5 times done
>>> numberOfRepeatitions=5
>>> numberOfRepatition=5
>>> numberOfRepeatitions=5
>>> numberOfRepeatitions=5
>>> numberOfRepeatitions=5
>>> numberOfRepeatitions=5
>>> # numberOfRepeatitions =5,5 times,done
>>> iNUmberOfsessions=125
>>> iNumberOfSessions=125
>>> iNumberOfSessions=125
>>> iNumberOfSessions=125
>>> iNumberOfSessions=125
>>> iNumberOfSessions=125
>>> # numberofsessions=125 ,5 times done
>>> number_of_admissions=145
>>> number_of_admissions=145
>>> number_of_admissions=145
>>> number_of_admissions=145
>>> number_of_admissions=145
>>> # nunmber_of_admissions=145,5 times done
>>> durationInHours=40
>>> durationInhours=40
>>> durationInHours=40
>>> durationInHours=40
>>> durationInHours=40
>>> #durationInHours=40,5 times done
