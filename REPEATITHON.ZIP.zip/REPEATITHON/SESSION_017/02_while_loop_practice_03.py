print('start of program-')
i_rj=0
while i_rj<5:
    print('value of i_rj:',i_rj)
    i_rj=i_rj+1
print('end of while loop')
print('value of i_rj at the end:',i_rj)
print('end of program')