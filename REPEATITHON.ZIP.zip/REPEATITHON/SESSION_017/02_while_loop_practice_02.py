print('start of program')
i_rj=0
while i_rj<5:
    print('Value of i_rj:',i_rj)
    i_rj=i_rj+1
print('End of while loop')
print('Value of i_rj at the end: ',i_rj)
print('End of program')
