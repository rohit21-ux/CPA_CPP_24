mass_of_object_1_in_kgs_rj = float(input('Enter mass of object 1 in kgs:'))
mass_of_object_2_in_kgs_rj = float(input('Enter mass of object 2 in kgs:'))
distance_between_objects_in_meters_rj = float(input('Enter distance between objects in meters:'))
universal_constant_of_gravitation_rj = 6.67 * 10 ** -11
gravitational_force_of_attraction_rj = (universal_constant_of_gravitation_rj * mass_of_object_1_in_kgs_rj *
                                     mass_of_object_2_in_kgs_rj) / (distance_between_objects_in_meters_rj ** 2)
print('Force of attracition:', gravitational_force_of_attraction_rj, 'Newton')
