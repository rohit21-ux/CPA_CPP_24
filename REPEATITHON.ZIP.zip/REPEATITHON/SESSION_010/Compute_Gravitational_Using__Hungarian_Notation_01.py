flMassOfObjectOneInKgs_rj = float(input('Enter mass of object 1 in kgs:'))
flMassOfObjectTwoInKgs_rj = float(input('Enter mass of object 2 in kgs:'))
flDistanceBetweenObjectsInMeters_rj = float(input('Enter distance between objects in meters:'))
flUniversalConstantOfGravitation_rj = 6.67 * (10 ** -11)
flForceOfGravitationInNewton_rj = (flUniversalConstantOfGravitation_rj * flMassOfObjectOneInKgs_rj *
                                 flMassOfObjectTwoInKgs_rj) / (flDistanceBetweenObjectsInMeters_rj ** 2)
print("Gravitational Force:", flForceOfGravitationInNewton_rj, 'Newton')
