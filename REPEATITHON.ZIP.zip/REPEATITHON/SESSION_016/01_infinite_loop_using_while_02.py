print('start of program')
i_rj=0
while True:
    i_rj=i_rj+1
    print(i_rj,'Hello!')
    a_rj=10
    b_rj=20
    c_rj=a_rj+b_rj
print('end of program')