print('start of program')

s_rj = input('Enter something:') # BLOCKING FUNCTION 
print(s_rj)

print('end of program') 
