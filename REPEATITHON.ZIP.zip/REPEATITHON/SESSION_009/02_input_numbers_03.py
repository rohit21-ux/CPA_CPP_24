print('Start of program')

s1_rj = input('Enter an integer : ')
n1_rj = int(s1_rj)

print('Entered integr is : ', n1_rj)

print('For detailed study : ')
print('s1_rj:', s1_rj)
print('n1_rj:', n1_rj)
print('type(s1_rj) : ', type(s1_rj))
print('type(n1_rj) : ', type(n1_rj))
print('detailed study finished')

s2_rj = input('Enter a fractional number : ')
f_num = float(s2_rj)
print('f_num : ', f_num)

print('End of program')

