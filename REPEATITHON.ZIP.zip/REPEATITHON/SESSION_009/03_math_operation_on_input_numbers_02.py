print('math operation on integers:')

# Input integer 1 and convert it in numerical format 
s1_rj = input('Enter number one:')
n1_rj = int(s1_rj)

# Input integer 2 and convert it in numerical format 
s2_rj = input('Enter number two:')
n2_rj = int(s2_rj)

# perform addition, subtraction, multiplication, division
# and power on input integers and store the results
# in different variables 
result_of_addition = n1_rj + n2_rj
result_of_subtraction = n1_rj - n2_rj
result_of_multiplication = n1_rj * n2_rj
result_of_division = n1_rj / n2_rj
result_of_power = n1_rj ** n2_rj

# print the results of operations 
print('addition:', result_of_addition)
print('subtraction:', result_of_subtraction)
print('mutiplication:', result_of_multiplication)
print('division:', result_of_division)
print('power:', result_of_power) 
