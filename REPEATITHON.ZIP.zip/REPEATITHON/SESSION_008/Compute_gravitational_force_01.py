m1_rj = float(input('Enter mass of object 1 in kgs : '))
m2_rj = float(input('Enter mass of object 2 in kgs : '))
r_rj = float(input('Enter the distance between the objects in meters : '))
G = 6.67 * 10 ** -11
F = (G * m1_rj * m2_rj) / (r_rj ** 2)
print('Gravitational Force is : ', F, 'Newton')
