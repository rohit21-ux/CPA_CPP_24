s_rj=int(input("Enter an integr:"))
r_rj=int(input("Enter an integr:"))

result_rj= s_rj>r_rj;
print("result of s_rj>r_rj is:",result_rj)

result_rj= s_rj>=r_rj;
print("result of s_rj>=r_rj is:",result_rj)

result_rj= s_rj<r_rj;
print("result of s_rj<r_rj is:",result_rj)

result_rj= s_rj<=r_rj;
print("result of s_rj<=r_rj is:",result_rj)

result_rj= s_rj==r_rj;
print("result of s_rj==r_rj is:",result_rj)

result_rj= s_rj!=r_rj;
print("result of s_rj!=r_rj is:",result_rj)



