print('Start of program')
n_rj= int(input('Enter an integer:'))
if n_rj>0:
    print(n_rj,'is a postive number')
    print('End of program.')
