print('Start of program')
n_rj =int(input('Enter an integer :'))
if n_rj>0:
    print(n_rj,'is a positive number')
elif n_rj<0:
    print(n_rj,'is a negative number')
else:
    print(n_rj,'is zero')
    print('End of program')
   

