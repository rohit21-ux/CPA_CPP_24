print('Start of program')
n_rj= int(input('Enter an integer:'))
if n_rj > 0:
    print(n_rj,"is a positive number") 
else:
    print(n_rj,"is either  a negative number or zero")
    print("End of program.")