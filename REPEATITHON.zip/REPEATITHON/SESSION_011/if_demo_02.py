print('Start of program')
n= int(input('Enter an integer:'))
if n>0:
    print(n,'is a postive number')
    print('End of program.')

