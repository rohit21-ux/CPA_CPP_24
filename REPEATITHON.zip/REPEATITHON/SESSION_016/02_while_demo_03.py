print('start of program')
print('start of while loop')
i_rj=1
while i_rj<=5:
    print('Repeatition number:',i_rj)
    i_rj=i_rj+1
print('end of while loop')
print('Value of i_rj after while loop ends:',i_rj)
print('end of program')
