print('Start of program')

s1 = input('Enter an integer : ')
n1 = int(s1)

print('Entered integr is : ', n1)

print('For detailed study : ')
print('s1:', s1)
print('n1:', n1)
print('type(s1) : ', type(s1))
print('type(n1) : ', type(n1))
print('detailed study finished')

s2 = input('Enter a fractional number : ')
f_num = float(s2)
print('f_num : ', f_num)

print('End of program')
