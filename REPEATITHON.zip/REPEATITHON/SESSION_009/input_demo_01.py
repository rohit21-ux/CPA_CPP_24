print('start of program')

s = input('Enter something:') # BLOCKING FUNCTION 
print(s)

print('end of program') 
