print('math operation on integers:')

#Input integer 1 and convert it in numerical format 
s1 = input('Enter number one:')
n1 = int(s1)

#Input integer 2 and convert it in numerical format 
s2 = input('Enter number two:')
n2 = int(s2)

#perform addition, subtraction, multiplication, division
#and power on input integers and store the results
#in different variables 
result_of_addition = n1 + n2
result_of_subtraction = n1 - n2
result_of_multiplication = n1 * n2
result_of_division = n1 / n2
result_of_power = n1 ** n2

# print the results of operations 
print('addition:', result_of_addition)
print('subtraction:', result_of_subtraction)
print('mutiplication:', result_of_multiplication)
print('division:', result_of_division)
print('power:', result_of_power) 
