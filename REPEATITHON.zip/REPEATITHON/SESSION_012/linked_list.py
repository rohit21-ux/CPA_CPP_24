class node:
    def __init__(self, data: int):
        self.data = data
        self.prev = None
        self.next = None

class linked_list:
    def __init__(self):
        self.root_node = node(0)
        self.root_node.prev = self.root_node
        self.root_node.next = self.root_node

    @staticmethod
    def generic_insert(beg_node, mid_node, end_node):
        mid_node.next = end_node
        mid_node.prev = beg_node
        beg_node.next = mid_node
        end_node.prev = mid_node

    def insert_end(self, new_data):
        linked_list.generic_insert(self.root_node.prev, node(new_data),
                                   self.root_node)

    def show(self):
        print('[START]<->', end='')
        run=self.root_node.next
        while run != self.root_node:
            print(f'[{run.data}]<->', end='')
            run = run.next
        print('[END]')


if __name__ == '__main__':
    L_rj = linked_list()
    L_rj.insert_end(100)
    L_rj.insert_end(200)
    L_rj.insert_end(300)
    L_rj.insert_end(400)
    L_rj.show() 