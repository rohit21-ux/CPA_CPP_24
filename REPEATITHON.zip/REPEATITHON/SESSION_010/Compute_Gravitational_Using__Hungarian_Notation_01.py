flMassOfObjectOneInKgs = float(input('Enter mass of object 1 in kgs:'))
flMassOfObjectTwoInKgs = float(input('Enter mass of object 2 in kgs:'))
flDistanceBetweenObjectsInMeters = float(input('Enter distance between objects in meters:'))
flUniversalConstantOfGravitation = 6.67 * (10 ** -11)
flForceOfGravitationInNewton = (flUniversalConstantOfGravitation * flMassOfObjectOneInKgs *
                                 flMassOfObjectTwoInKgs) / (flDistanceBetweenObjectsInMeters ** 2)
print("Gravitational Force:", flForceOfGravitationInNewton, 'Newton')
