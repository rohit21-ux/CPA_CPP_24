mass_of_object_1_in_kgs = float(input('Enter mass of object 1 in kgs:'))
mass_of_object_2_in_kgs = float(input('Enter mass of object 2 in kgs:'))
distance_between_objects_in_meters = float(input('Enter distance between objects in meters:'))
universal_constant_of_gravitation = 6.67 * 10 ** -11
gravitational_force_of_attraction = (universal_constant_of_gravitation * mass_of_object_1_in_kgs *
                                     mass_of_object_2_in_kgs) / (distance_between_objects_in_meters ** 2)
print('Force of attracition:', gravitational_force_of_attraction, 'Newton')
